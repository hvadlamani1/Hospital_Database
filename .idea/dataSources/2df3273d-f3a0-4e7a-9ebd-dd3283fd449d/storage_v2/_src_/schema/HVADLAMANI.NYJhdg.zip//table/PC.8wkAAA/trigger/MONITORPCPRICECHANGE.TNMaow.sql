create trigger MONITORPCPRICECHANGE
    after ???
    on PC
    for each row
Begin
INSERT INTO ProductMonitoring (modelNum, prodType, oldPrice, newPrice, modificationDate) 
VALUES (:Old.model, 'PC', :old.price, :new.price, to_char(sysdate,'dd-mm-yyyy:hh24:mi') );

END;
/

