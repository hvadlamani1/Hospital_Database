create view PERSONNAMEFREQUENCY as
select FirstName, count(*) as CNT from Person Group by FirstName
/

