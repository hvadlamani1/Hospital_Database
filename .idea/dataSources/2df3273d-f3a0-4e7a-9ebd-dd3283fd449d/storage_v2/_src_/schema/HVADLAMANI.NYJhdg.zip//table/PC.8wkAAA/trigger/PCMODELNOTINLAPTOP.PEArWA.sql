create trigger PCMODELNOTINLAPTOP
    after ???
    on PC
    for each row
DECLARE sameCount INT;
BEGIN
    SELECT COUNT(*) INTO sameCount FROM Laptop 
    WHERE Laptop.model = :NEW.model;

    IF sameCount > 0 THEN
        RAISE_APPLICATION_ERROR(-20004, 'PC Model Number already exists in Laptop table');
    END IF;
END;
/

