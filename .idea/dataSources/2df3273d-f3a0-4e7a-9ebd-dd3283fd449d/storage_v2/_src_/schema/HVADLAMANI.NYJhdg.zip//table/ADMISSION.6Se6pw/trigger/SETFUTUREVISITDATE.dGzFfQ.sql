create trigger SETFUTUREVISITDATE
    before insert
    on ADMISSION
    for each row
DECLARE 
    serviceType VARCHAR2(50);
    futureDay NUMBER;
    newMonth NUMBER;
    newYear NUMBER;
BEGIN
    SELECT rs.ServiceType INTO serviceType
    FROM Admission a JOIN StayIN s on a.admissionnum = s.admissionnum 
    JOIN RoomService rs on rs.roomnum = s.roomnum
    WHERE ROWNUM = 1;
    

    IF serviceType = 'Emergency' THEN
        futureDay := EXTRACT(DAY FROM :NEW.AdmissionDate);
        newMonth := EXTRACT(MONTH FROM :NEW.AdmissionDate) + 2;
        newYear := EXTRACT(YEAR FROM :NEW.AdmissionDate);

        IF newMonth > 12 THEN
            newMonth := newMonth - 12;
            newYear := newYear + 1;
        END IF;

        :NEW.futureVisit := TO_DATE(newYear || '-' || newMonth || '-' || futureDay, 'YYYY-MM-DD');
    END IF;
END;
/

