create trigger LAPTOPMODELNOTINPC
    before insert
    on LAPTOP
    for each row
DECLARE sameCount INT;
BEGIN
    SELECT COUNT(*) INTO sameCount FROM PC 
    WHERE PC.model = :NEW.model;

    IF sameCount > 0 THEN
        RAISE_APPLICATION_ERROR(-20004, 'Laptop Model Number already exists in PC table');
    END IF;
END;
/

