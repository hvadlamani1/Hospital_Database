create view OVERLOADEDWPI as
SELECT E.EmployeeID, E.FName, E.LName
	From Employee E
	Where EmployeeID IN (Select DoctorID from DoctorsLoad Where (GraduatedFrom = 'WPI') AND (load = 'Overloaded'))
/

