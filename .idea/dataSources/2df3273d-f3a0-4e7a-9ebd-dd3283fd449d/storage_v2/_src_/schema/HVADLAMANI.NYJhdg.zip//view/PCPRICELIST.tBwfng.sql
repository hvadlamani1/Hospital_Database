create view PCPRICELIST as
Select model, price from PC
/

