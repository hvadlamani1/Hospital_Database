create view DOCTORSLOAD as
(Select E.DoctorID, D.graduatedFrom, 'Overloaded' as load
	From Examine E Join Admission A on E.AdmissionNum = A.AdmissionNum
	Join Doctor D on E.DoctorID = D.EmployeeID
	Group by E.DoctorID, D.graduatedFrom
	Having count(E.AdmissionNum) > 10)
	UNION
	-- get underloaded doctors
	(Select E.DoctorID, D.graduatedFrom, 'Underloaded' as load
	From Examine E Join Admission A on E.AdmissionNum = A.AdmissionNum
	Join Doctor D on E.DoctorID = D.EmployeeID
	Group by E.DoctorID, D.graduatedFrom
	Having count(E.AdmissionNum) <= 10)
	UNION
	-- get underloaded doctors with 0 examines
	(Select D.EmployeeID, D.graduatedFrom, 'Underloaded' as load
	From Doctor D
	Where D.EmployeeID NOT IN (Select E.DoctorID From Examine E))
/

