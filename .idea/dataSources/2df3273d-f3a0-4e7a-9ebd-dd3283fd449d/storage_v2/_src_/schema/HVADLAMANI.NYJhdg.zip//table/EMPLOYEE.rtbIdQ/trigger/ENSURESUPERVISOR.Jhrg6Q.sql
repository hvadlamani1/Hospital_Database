create trigger ENSURESUPERVISOR
    before insert or update
    on EMPLOYEE
    for each row
DECLARE
    supervisorRankForReg VARCHAR(20);
    supervisorRankForDiv VARCHAR(20);
BEGIN
    -- regular employee must have a supervisor that is a division manager
    IF :NEW.EmpRank = 'Regular' THEN
        IF :NEW.SupervisorID IS NULL THEN
            RAISE_APPLICATION_ERROR(-20001, 'Regular employees must have "Division Manager" supervisor.');
        END IF;
        
        SELECT EmpRank INTO supervisorRankForReg
        FROM Employee
        WHERE EmployeeID = :NEW.SupervisorID;
        
        IF supervisorRankForReg != 'Division Manager' THEN
            RAISE_APPLICATION_ERROR(-20002, 'Regular employees must have supervisor with employee rank "Division Manager."');
        END IF;
    END IF;
    -- division manager must have a supervisor that is a division manager
    IF :NEW.EmpRank = 'Division Manager' THEN
        IF :NEW.SupervisorID IS NULL THEN
            RAISE_APPLICATION_ERROR(-20003, 'Division managers must have "General Manager" supervisor.');
        END IF;
        
        SELECT EmpRank INTO supervisorRankForDiv
        FROM Employee
        WHERE EmployeeID = :NEW.SupervisorID;
        
        IF supervisorRankForDiv != 'General Manager' THEN
            RAISE_APPLICATION_ERROR(-20004, 'Division managers must have supervisor with employee rank "General Manager."');
        END IF;
    END IF;
    -- general manager must not have a supervisor
    IF :NEW.EmpRank = 'General Manager' THEN
        IF :NEW.SupervisorID IS NOT NULL THEN
            RAISE_APPLICATION_ERROR(-20005, 'General Managers must not have a supervisor.');
        END IF;
    END IF;
    -- employee rank must be a valid option
    IF :NEW.EmpRank NOT IN ('General Manager', 'Division Manager', 'Regular') THEN
        RAISE_APPLICATION_ERROR(-20006, 'Employee rank must be one of "General Manager", "Division Manager", "Regular".');
    END IF;
END;
/

