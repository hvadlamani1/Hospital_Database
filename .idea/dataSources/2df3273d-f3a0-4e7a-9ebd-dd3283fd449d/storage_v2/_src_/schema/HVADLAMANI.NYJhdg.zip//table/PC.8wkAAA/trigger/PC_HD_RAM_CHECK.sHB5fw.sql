create trigger PC_HD_RAM_CHECK
    after ???
    on PC
    for each row
Begin
IF :New.HD < :New.Ram * 1024 THEN 
RAISE_APPLICATION_ERROR(-20003, 'The hard disk (GB) must be at least 100 times greater than the RAM (MB).');

END IF;
 END;
/

