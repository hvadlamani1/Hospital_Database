create trigger CHECKPRODUCTCONSISTENT
    after ???
    on PRODUCT
    for each row
DECLARE prodCount INT; 
BEGIN
    IF :NEW.type = 'PC' THEN
        SELECT COUNT(*) INTO prodCount FROM PC
        WHERE PC.model = :NEW.model;

        IF prodCount = 0 THEN
            RAISE_APPLICATION_ERROR(-20003, 'Product of PC type is not in PC table');
        END IF;

    ELSIF :NEW.type = 'Laptop' THEN
        SELECT COUNT(*) INTO prodCount FROM Laptop
        WHERE Laptop.model = :NEW.model;

        IF prodCount = 0 THEN
            RAISE_APPLICATION_ERROR(-20003, 'Product of Laptop type is not in Laptop table');
        END IF;

    ELSIF :NEW.type IS NULL THEN
        SELECT COUNT(*) INTO prodCount FROM PC
        WHERE PC.model = :NEW.model;

        IF prodCount > 0 THEN
            RAISE_APPLICATION_ERROR(-20003, 'Product type is null, but model exists in PC table');
        END IF;

        SELECT COUNT(*) INTO prodCount FROM Laptop
        WHERE Laptop.model = :NEW.model;

        IF prodCount > 0 THEN
            RAISE_APPLICATION_ERROR(-20003, 'Product type is null, but model exists in Laptop table');
        END IF;
    END IF;
END;
/

