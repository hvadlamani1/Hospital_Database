create trigger CHECKEQUIPMENTINSPECTION
    before insert or update
    on EQUIPMENT
    for each row
DECLARE
    technician_exists NUMBER;
BEGIN
    IF :NEW.LastInspection IS NULL 
       OR EXTRACT(YEAR FROM :NEW.LastInspection) < EXTRACT(YEAR FROM SYSTIMESTAMP)
       OR (EXTRACT(YEAR FROM :NEW.LastInspection) = EXTRACT(YEAR FROM SYSTIMESTAMP) 
           AND EXTRACT(MONTH FROM :NEW.LastInspection) < EXTRACT(MONTH FROM SYSTIMESTAMP)) THEN
        
        SELECT COUNT(*)
        INTO technician_exists
        FROM CanRepairEquipment C
        WHERE C.EquipmentType = :NEW.TypeID;

        IF technician_exists > 0 THEN
            :NEW.LastInspection := SYSTIMESTAMP;
        END IF;
        
    END IF;
END;
/

