create trigger CHECKEQUIPMENTINSPECTION
    before insert or update
    on EQUIPMENT
    for each row
DECLARE
    technician_exists NUMBER;
BEGIN
    IF :NEW.LastInspection IS NULL 
       OR :NEW.LastInspection < CAST(ADD_MONTHS(SYSTIMESTAMP, -1) AS TIMESTAMP) THEN

        SELECT COUNT(*)
        INTO technician_exists
        FROM CanRepairEquipment C
        WHERE C.Equipmenttype = :NEW.typeID;

        IF technician_exists > 0 THEN
            :NEW.LastInspection := SYSTIMESTAMP;
        END IF;

    END IF;
END;
/

