create view EXTENDEDPC as
SELECT Product.manufacturer, Product.model, PC.speed, PC.ram, PC.hd, rd, PC.price, Product.type
From Product join PC on Product.model = PC.model
/

