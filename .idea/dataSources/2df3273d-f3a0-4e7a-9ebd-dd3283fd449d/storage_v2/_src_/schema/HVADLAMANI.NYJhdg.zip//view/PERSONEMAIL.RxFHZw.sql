create view PERSONEMAIL as
select Login, FirstName, Lastname, Login || '@wpi.edu' as Email
    from Person
/

