create trigger REQUIRECOMMENTONICU
    before insert or update
    on EXAMINE
    for each row
DECLARE
    icuNum NUMBER;
BEGIN
    SELECT COUNT(*)
    INTO icuNum
    FROM StayIn S
    WHERE S.AdmissionNum = :NEW.AdmissionNum
    AND S.RoomNum IN (
        SELECT R.RoomNum
        FROM RoomService R
        WHERE R.ServiceType = 'ICU');
    IF icuNum > 0 AND :NEW.ExamineComment IS NULL THEN
        RAISE_APPLICATION_ERROR(-20001, 'Doctor must leave a comment when visiting a patient in the ICU');
    END IF;
END;
/

