create view PERSONAGE as
select Login, FirstName, LastName, EXTRACT(YEAR FROM SYSDATE )- EXTRACT(YEAR FROM DOB) as Age from person
/

