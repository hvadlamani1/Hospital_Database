create trigger CHECKPCCONSISTENT
    after ???
    on PC
    for each row
DECLARE
    pcCount INT;
BEGIN
    SELECT COUNT(*) INTO pcCount FROM Product
    WHERE model = :NEW.model AND type = 'PC';

    IF pcCount = 0 THEN
        INSERT INTO Product (model, manufacturer, type) 
        VALUES (:NEW.model, NULL, 'PC');
    END IF;
END;
/

