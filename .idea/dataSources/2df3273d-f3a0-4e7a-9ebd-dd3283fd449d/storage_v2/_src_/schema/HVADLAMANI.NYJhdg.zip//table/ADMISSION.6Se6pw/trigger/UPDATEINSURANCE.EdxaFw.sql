create trigger UPDATEINSURANCE
    before insert or update of TOTALPAYMENT
    on ADMISSION
    for each row
BEGIN
    :NEW.InsurancePayment := 0.65 * :NEW.TotalPayment;
END;
/

