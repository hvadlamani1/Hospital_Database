create trigger UPDATEINSURANCE
    before insert or update of TOTALPAYMENT
    on ADMISSION
    for each row
BEGIN
    IF (:NEW.InsurancePayment / :NEW.TotalPayment < 0.65) THEN
        :NEW.InsurancePayment := 0.65 * :NEW.TotalPayment;
    END IF;
END;
/

