create trigger CHECKLAPTOPCONSISTENT
    before insert or update
    on LAPTOP
    for each row
DECLARE
    lapCount INT;
BEGIN
    SELECT COUNT(*) INTO lapCount FROM Product
    WHERE model = :NEW.model AND type = 'Laptop';

    IF lapCount = 0 THEN
        INSERT INTO Product (model, manufacturer, type) 
        VALUES (:NEW.model, NULL, 'Laptop');
    END IF;
END;
/

