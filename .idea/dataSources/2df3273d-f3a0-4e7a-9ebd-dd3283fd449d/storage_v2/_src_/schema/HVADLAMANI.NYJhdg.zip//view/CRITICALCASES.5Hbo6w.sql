create view CRITICALCASES as
SELECT Patient.SSN, Patient.FirstName, Patient.LastName, COUNT(DISTINCT Admission.AdmissionNum) AS numberOfAdmissionsToICU
    FROM StayIn 
    JOIN Admission ON StayIn.AdmissionNum = Admission.AdmissionNum
    JOIN RoomService ON StayIn.RoomNum = RoomService.RoomNum
    JOIN Patient ON Admission.PatientSSN = Patient.SSN
    WHERE RoomService.ServiceType = 'ICU'
    GROUP BY Patient.SSN, Patient.FirstName, Patient.LastName
    HAVING COUNT(DISTINCT Admission.AdmissionNum) >= 2
/

