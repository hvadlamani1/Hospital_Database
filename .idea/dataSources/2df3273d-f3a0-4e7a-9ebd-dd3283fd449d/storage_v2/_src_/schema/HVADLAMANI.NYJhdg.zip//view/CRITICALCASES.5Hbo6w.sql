create view CRITICALCASES as
SELECT Patient.SSN, Patient.FirstName, Patient.LastName, COUNT(Patient.SSN) AS VisitCount
    FROM StayIn 
    JOIN Admission ON StayIn.AdmissionNum = Admission.AdmissionNum
    JOIN RoomService ON StayIn.RoomNum = RoomService.RoomNum
    JOIN Patient ON Admission.PatientSSN = Patient.SSN
    WHERE RoomService.ServiceType = 'ICU'
    GROUP BY Patient.SSN, Patient.FirstName, Patient.LastName
    HAVING COUNT(Patient.SSN) > 2
/

